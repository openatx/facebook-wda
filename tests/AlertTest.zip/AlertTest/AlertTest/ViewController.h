//
//  ViewController.h
//  AlertTest
//
//  Created by 蓝畔 on 2017/8/28.
//  Copyright © 2017年 tianshi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

